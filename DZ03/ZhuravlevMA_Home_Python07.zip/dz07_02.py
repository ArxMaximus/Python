crt = ('ab', 'abcd', 'cde', 'abc', 'def')
s = 'ab'

print('Yes' if s in crt else 'No')