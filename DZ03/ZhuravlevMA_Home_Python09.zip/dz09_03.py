l1 = ['color', 'fruit', 'pet']
l2 = ['blue', 'apple', 'dog']

d = {l1[i]:l2[i] for i in range(len(l1))}

print(d)