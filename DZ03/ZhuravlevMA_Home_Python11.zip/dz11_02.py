mult = lambda a, b, c: a * b * c

print(mult(2, 5, 5))